
"use strict";

let keyframeGraphMsg = require('./keyframeGraphMsg.js');
let keyframeMsg = require('./keyframeMsg.js');

module.exports = {
  keyframeGraphMsg: keyframeGraphMsg,
  keyframeMsg: keyframeMsg,
};
